package com.learn.even;



import java.util.Scanner;

public class EvenNumbersListing {

	public static void main(String[] args) {
		int i=0;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter value of n:");
		int n = sc.nextInt();
		
		for(i=1;i<=n;i++ ) {
			if(i%2==0) {
				System.out.println(+i);
			}
				
		}

	}
}