package com.repeatingdecimal;

public class Main {

	public static void main(String[] args) {
		String x;
		Divider div =new Divider();
		 x = div.divide(10, 3);
		 System.out.println(x+" ");

	}

}
